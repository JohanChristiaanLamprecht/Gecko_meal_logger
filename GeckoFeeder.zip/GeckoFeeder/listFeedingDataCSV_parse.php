<?php

// Test connection with the database. 
include 'dbconf.php';
$db = mysqli_connect($dbWebAddress, $dbUserName, $dbPassword, $dbName);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}

$separator = ",";
// Set up a query to get data from the database.
$q = "SELECT * FROM feedings";
$result = mysqli_query($db, $q);
if ($result)
{
    // Set up CSV headings.
    $temp = "feeding_id".$separator."feeder_name".$separator."amount".$separator."date";
    echo $temp;
    echo nl2br("\n");
    // Display each row of data from the database in CSV format.
    while ($row = mysqli_fetch_assoc($result))
    {
        $temp = $row['feeding_id'].$separator.$row['feeder_name'].$separator.$row['amount'].$separator.$row['date'];
        echo $temp;
        echo nl2br("\n");
    }
}