<?php
// Database Server Address
$dbWebAddress = "127.0.0.1";
// Database Admin Username
$dbUserName = "root";
// Database Admin Password
$dbPassword = "";
// Database Name
$dbName = "gecko_feeding_db";
?>