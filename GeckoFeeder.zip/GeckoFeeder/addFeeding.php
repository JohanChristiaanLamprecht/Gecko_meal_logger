<link rel='stylesheet' href='style.css'>
<div style="text-align: center;">
    <br>
    <!-- Home Button. -->
    <input type="submit" name="Home_button" value="HOME" onclick="location.href='index.php'"><br><br>
    
    <section>
        <div>
            <?php
            // Test connection with the database. 
            include 'dbconf.php';
            $db = mysqli_connect($dbWebAddress, $dbUserName, $dbPassword, $dbName);
            if (mysqli_connect_errno()) 
            {
                echo "Failed to connect to MySQL: " . mysqli_connect_error();
                exit();
            }
            
            // Set up a query to get data from the database.
            $q = "SELECT * FROM feeders";
            $result = mysqli_query($db, $q);
            if ($result)
            {
                $temp = "Add Meal";
                echo "<h2>" . $temp . "</h2>";
                // Set up a field to input the number of feeders consumed.
                echo "
                <form action='addFeeding_parse.php' method='post'>
                <input type='number' id='amount' name='amount' min='1' max='50' style='width: 120px'><br><br>
                ";
                // Construct a button for each type of feeder in the database.
                while ($row = mysqli_fetch_assoc($result))
                {
                    $temp = $row['feeder_name'];
                    echo "
                    <input type='submit' name='feeder_name' value=".$temp."><br><br>
                    ";
                }
                echo "</form>";
            }
            ?>
        </div>
    </section>
</div>