<link rel='stylesheet' href='style.css'>
<div style="text-align: center;">
    <br>
    <!-- Home Button. -->
    <input type="submit" name="Home_button" value="HOME" onclick="location.href='index.php'"><br><br>
    
    <section>
        <div>
            <form action="addFeeder_parse.php" method="post">
            <h2>Add New Feeder</h2>
            <!-- Input Text. -->
            <p>Feeder name:<br><textarea type="text" name="name" placeholder="Name..." style="resize: none; width: 700px; height: 75px; font-size: 50px;"></textarea><br></p>
            <!-- Submission Button. -->
            <input type="submit" name="submit" value="Add Feeder"><br><br>
            </form>
        </div>
    </section>
</div>