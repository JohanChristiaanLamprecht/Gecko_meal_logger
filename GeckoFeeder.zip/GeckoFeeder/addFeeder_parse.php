<?php

$name = $_POST['name'];

// Test connection with the database. 
include 'dbconf.php';
$db = mysqli_connect($dbWebAddress, $dbUserName, $dbPassword, $dbName);
if (mysqli_connect_errno()) 
{
    echo "Failed to connect to MySQL: " . mysqli_connect_error();
    exit();
}

// Prepare MySQL statement to insert data into the database.
$q = "insert into feeders (feeder_name) values (?);";
$stmt = mysqli_stmt_init($db);
if (!mysqli_stmt_prepare($stmt, $q))
{
    echo "error: stmtfail";
}
mysqli_stmt_bind_param($stmt, "s", $name);
mysqli_stmt_execute($stmt);
mysqli_stmt_close($stmt);

header('location: index.php?Submit=Successfully');
exit();
/**************************************************/
// echo 'Data Submit Successfully';
/**************************************************/