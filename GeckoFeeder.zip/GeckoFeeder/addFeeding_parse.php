<?php

$amount = $_POST['amount'];
$feeder_name = $_POST['feeder_name'];

// If the amount is set, proceed to insert data into the database.
if ($amount)
{
    // Test connection with the database. 
    include 'dbconf.php';
    $db = mysqli_connect($dbWebAddress, $dbUserName, $dbPassword, $dbName);
    if (mysqli_connect_errno()) 
    {
        echo "Failed to connect to MySQL: " . mysqli_connect_error();
        exit();
    }
    
    // Prepare MySQL statement to insert data into the database.
    $q = "insert into feedings (feeder_name, amount, date) values (?,?,?);";
    $stmt = mysqli_stmt_init($db);
    if (!mysqli_stmt_prepare($stmt, $q))
    {
        echo "error: stmtfail";
    }
    mysqli_stmt_bind_param($stmt, "sss", $feeder_name, $amount, date("Y-m-d"));
    mysqli_stmt_execute($stmt);
    mysqli_stmt_close($stmt);
    
    header('location: index.php?Submit=Successfully');
}
else
{
    header('location: index.php?Submit=NoAmountSet');
}
exit();