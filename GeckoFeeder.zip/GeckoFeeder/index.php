<link rel='stylesheet' href='style.css'>
<div style="text-align: center;">
    <br>
    <!-- Navigation buttons. -->
    <input type="submit" name="Add_feeder_button" value="Add Feeder" onclick="location.href='addFeeder.php'"><br/><br/>
    <input type="submit" name="Add_meal_button" value="Add Meal" onclick="location.href='addFeeding.php'"><br/><br/>
    <input type="submit" name="List_meal_data_button" value="List Meal Data" onclick="location.href='listFeedingData_parse.php'"><br/><br/>
    <input type="submit" name="List_feeding_data_button" value="List Meal Data CSV" onclick="location.href='listFeedingDataCSV_parse.php'"><br/><br/>
</div>