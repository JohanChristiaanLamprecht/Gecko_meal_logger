<?php

echo "<link rel='stylesheet' href='style.css'>";
// Home Button.
echo "
<div style='text-align: center;'>
    <br>
    <input type='submit' name='Home_button' value='HOME' onclick="."location.href='index.php'"."><br><br>
";

// Test connection with the database. 
include 'dbconf.php';
$db = mysqli_connect($dbWebAddress, $dbUserName, $dbPassword, $dbName);
if (mysqli_connect_errno()) {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  exit();
}

// Set up style for tables.
echo"<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}
td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}
tr:nth-child(even) {
  background-color: #dddddd;
}
</style>";

$separator = "</td><td>";
// Set up a query to get data from the database.
$q = "SELECT * FROM feedings";
$result = mysqli_query($db, $q);
if ($result)
{
    // Set up table headings.
    $temp = "<th>feeding_id"."</th><th>"."feeder_name"."</th><th>"."amount"."</th><th>"."date</th>";
    echo "<table>";
    echo $temp;
    // Display each row of data from the database in the table.
    while ($row = mysqli_fetch_assoc($result))
    {
        $temp = "<tr><td>".$row['feeding_id'].$separator.$row['feeder_name'].$separator.$row['amount'].$separator.$row['date']."</td></tr>";
        echo $temp;
    }
    echo "</table>";
}